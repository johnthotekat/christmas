/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package articulatenew;

/**
 *
 * @author ashwatiteresajoseph
 */
public class Player {
	// The things shown below are part of the backend data structure, ****you need some way of passing it to the GUI for representation as a JTable.
	int playerId; // use this id to give each player object the identification number. When they play: scoringGrid[callingPlayer.id][calledPlayer.id] = scoreTheyGot --> this score should be ready as it increments each time they update
	String playerName;
	int playerScore;
        
           
        public static int id = 0;
        
        
	Player(String playerName) {
		this.playerId = id;
                id++;
		this.playerName = playerName;
		this.playerScore = 0;
	}
	// commented out below method to see if scores can be updated each time the "Correct" button is clicked 
	/*
        public void updateScore(int points){
		this.playerScore+=points;
	}
        */
        public void updateScore() {
		this.playerScore += 1;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getPlayerScore() {
		return playerScore;
	}

	public void setPlayerScore(int playerScore) {
		this.playerScore = playerScore;
	}
        
        
}
