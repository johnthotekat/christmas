/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package articulatenew;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ashwatiteresajoseph
 */
public class Countdown extends JFrame {
    
    public Countdown()
  {
    
    final long THIRTY_MINUTES = 60000;
    final java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("mm : ss");
    final JLabel clock = new JLabel(sdf.format(new Date(THIRTY_MINUTES)),JLabel.CENTER);
    int x = 0;
    ActionListener al = new ActionListener(){
      long x = THIRTY_MINUTES - 1000;
      public void actionPerformed(ActionEvent ae){
        clock.setText(sdf.format(new Date(x)));
        x -= 1000;}};
    new javax.swing.Timer(1000, al).start();
    JPanel jp = new JPanel();
    jp.add(clock);
    getContentPane().add(jp);
    pack();
  }
  public static void main(String args[]){new Countdown().setVisible(true);}
    
}
