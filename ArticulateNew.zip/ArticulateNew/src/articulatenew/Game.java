/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package articulatenew;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author ashwatiteresajoseph
 */
public class Game {


    private List<Player> playersList;
    private int noOfRounds;

    public int getNoOfRounds() {
        return noOfRounds;
    }

    public void setNoOfRounds(int noOfRounds) {
        this.noOfRounds = noOfRounds;
    }
    
    
    public List<Player> getPlayerList() {
        return playersList;
    }
    
    public Player getPlayerById(int id) {
        for (int i = 0; i < playersList.size(); i++) {
            if (playersList.get(i).getPlayerId() == id) {
                return playersList.get(i);
            }
            
        }
        return null;
    
    }
    
    public Game() {
        this.playersList = new ArrayList<>();
    }
    
    public void addPlayer(Player p) {
        playersList.add(p);
    }
    
    public int getPlayerCount() {
        return playersList.size();
    }

    public static void main(String args[]) {
        
    }
    
    public List<Player> getRandomPlayerNames(int n) {
        List<Player> randomNames = new ArrayList<Player>();
        Collections.shuffle(playersList);
        for (int i = 0; i < n; i++) {
            randomNames.add(playersList.get(i));
        }
        sortPlayerList();
        return randomNames;
    }
    
    private void sortPlayerList() {
        int n = playersList.size();
        Player playerTemp = null;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < n - i; j++) {
                if (playersList.get(j-1).getPlayerId() > playersList.get(j).getPlayerId()) {
                    playerTemp = playersList.get(j-1);
                    playersList.set(j - 1, playersList.get(j));
                    playersList.set(j, playerTemp);
                }
            }
        }
    }
    
    public void create2DScoringGrid() {
        int n = playersList.size();
        int[][] scoringGrid2DArray = new int[n][n];
        // need to find a way how to display this info or this grid on the GUI form as a JTable
    }

    
}
